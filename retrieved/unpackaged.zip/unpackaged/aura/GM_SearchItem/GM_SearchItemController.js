({
    doInit : function(component,helper,event){
        var action = component.get("c.searchForMovies");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.moviesSearch",returnValue);
            }
        });

        $A.enqueueAction(action);
    },


    redirectToDetails : function(component, event, helper) {
      var navService = component.find("navService");
      var pageReference = {
            type: 'standard__component',
            attributes: {
             "componentName": "c__GM_MovieDetails"
           },
           state: {
               "c__id": event.currentTarget.id
           }
       }
      navService.navigate(pageReference);
     }

})
({
    doInit : function(component,helper,event){

        var action = component.get("c.popularMovies");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.moviesPopular",returnValue);
                component.set("v.loaded",true);
            }
        });


        $A.enqueueAction(action);

    },


    redirectToDetails : function(component, event, helper) {

            component.set("v.movieId",event.currentTarget.id);
            var id = component.get("v.movieId");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_MovieDetails",
                componentAttributes: {
                    movieId : id
                }
            });
            evt.fire();

     },

     goNext6 : function (component, event, helper){
         if(component.get("v.end")<20){
             component.set("v.start",component.get("v.start")+6);
             component.set("v.end", component.get("v.end") + 6);
         }
         event.preventDefault();


     },

     goPrev6 : function (component, event, helper){
         if(component.get("v.start")>0){
           component.set("v.start",component.get("v.start")-6);
           component.set("v.end", component.get("v.end") - 6);
        }
        event.preventDefault();
    }


})
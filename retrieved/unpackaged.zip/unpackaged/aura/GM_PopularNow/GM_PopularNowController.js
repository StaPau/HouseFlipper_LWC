({
    onInit : function (component,event,helper){
        component.set("v.loaded",true);

    }
})
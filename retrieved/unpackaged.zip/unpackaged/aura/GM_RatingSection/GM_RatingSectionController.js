({
    onInit : function (component,event,helper){
        helper.getReviews(component);
        helper.getUser(component);
    },

    handleSectionToggle: function (cmp, event) {
        var openSections = event.getParam('openSections');

        if (openSections.length === 0) {
            cmp.set('v.activeSectionsMessage', "All sections are closed");
        } else {
            cmp.set('v.activeSectionsMessage', "Open sections: " + openSections.join(', '));
        }
    },

    handleSubmitClick : function (component,event,handler){

        var textarea= component.find("myTextArea");
        var reviewContent = textarea.get("v.value");
        var user = component.get('v.userInfo.Name');
        var rate = component.get('v.newRating');
        var id = component.get('v.movieId');
        var action = component.get("c.addNewReview");
            action.setParams({
                movieId : id,
                rate : rate,
                review : reviewContent
            });

        var previousRate = component.get("v.previousRating");
        var previousVotes = component.get("v.previousVotesNumber");
        var newVotes = previousVotes+1;
        var sumToAddRate = previousRate*previousVotes;
        var sumAddedRate = sumToAddRate+rate;
        var newRate = sumAddedRate/newVotes;

        component.set("v.previousVotesNumber",newVotes);
        component.set('v.previousRating');
        $A.enqueueAction(action);
        $A.get("e.force:refreshView").fire();
    },

    deleteReview : function (component,event,helper){
        component.set("v.ratingId",event.currentTarget.id);
        var movie = component.get("v.movieId");
        var rating = component.get("v.ratingId");
        console.log(movie+', '+rating);
        var action = component.get("c.deleteMyReview");
        action.setParams({
            ratingId : rating
        });
        component.set("v.alreadyRated",false);
        $A.enqueueAction(action);

        $A.get("e.force:refreshView").fire();

    }
})
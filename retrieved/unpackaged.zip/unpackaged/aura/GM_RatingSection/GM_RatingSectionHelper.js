({
    getReviews : function (component){
        var movie = component.get("v.movieId");
        var action = component.get("c.getMovieReviews");
        action.setParams({
            id : parseInt(movie)
            });
        action.setCallback(this, function(response){
                var state = response.getState();
                if(state === "SUCCESS"){
                    var returnValue = response.getReturnValue();
                    var returnBackwards=[];
                    for(let i=0; i<returnValue.results.length; i++){
                        var oldIndex = returnValue.results.length-1-i;
                        returnBackwards[i] = returnValue.results[oldIndex];
                    }
                    component.set("v.reviews",returnBackwards);
                }
            });

        $A.enqueueAction(action);
    },

    getUser : function (component){
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.userInfo", storeResponse);
                console.log(component.get('v.userInfo'));
                this.getMovieUserReviews(component);
            }
        });
        $A.enqueueAction(action);
    },

    getMovieUserReviews : function (component){
        var id = component.get('v.movieId');
        var user = component.get('v.userInfo.Id');
        console.log(user.id);
        var action = component.get("c.getAllRatings");
            action.setParams({
                movieId : id
            });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var returnBackwards=[];
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();

                for(let i=0; i<storeResponse.length; i++){
                    var oldIndex = storeResponse.length-1-i;
                    returnBackwards[i] = storeResponse[oldIndex];
                }

                returnBackwards.forEach(review => {
                    review.Created_At__c = review.Created_At__c.replace("T"," ");
                    var n = review.Created_At__c.lastIndexOf(' ');
                    review.Created_At__c = review.Created_At__c.substring(0,n);
                });

               for(let review of returnBackwards){
                   console.log(user);
                   console.log(review.CreatedById);
                   if(review.CreatedById == user){
                       component.set('v.alreadyRated',true);
                       break;
                   }
               }

                component.set("v.movieReviewsUser", returnBackwards);
            }
        });
        $A.enqueueAction(action);
    }
})
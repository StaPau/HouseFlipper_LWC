({
    doInit : function(component,event,helper){
        helper.getTopMovies(component);
        component.set('v.loaded',true);
    },

    searchButtonHandle : function(component,helper,event){
        var searchInput = component.get("v.searchInput");
        let searchObject = {
            'title' : searchInput
        };
        var action = component.get("c.searchForMovies");
        action.setParams({
            search :{
                title : searchObject.title
            },
            page : 1
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.moviesSearch",returnValue.results);
                component.set("v.searchResponse",returnValue);
                component.set('v.isSearchClicked',true);
            }
        });

        $A.enqueueAction(action);
        component.set('v.loaded',true);
    },

    goNext : function (component,event,helper){
        var searchInput = component.get("v.searchInput");
        let searchObject = {
            'title' : searchInput
        };
        var nextPage = component.get('v.actualPage')+1;
        var lastPage = component.get('v.searchResponse.total_pages');
        if(nextPage != lastPage+1){
            component.set('v.actualPage',nextPage);
            helper.getResults(component,searchObject,nextPage);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        }

    },

    goPrev : function (component,event,helper){
        var searchInput = component.get("v.searchInput");
        let searchObject = {
            'title' : searchInput
        };
        var prevPage = component.get('v.actualPage')-1;
        if(prevPage != 0){
            component.set('v.actualPage',prevPage);
            helper.getResults(component,searchObject,prevPage);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        }

    },

    goFirst : function (component, event, helper){
        var searchInput = component.get("v.searchInput");
        let searchObject = {
            'title' : searchInput
        };
//        var page = component.get('v.actualPage')-1;
        component.set('v.actualPage',1);
        helper.getResults(component,searchObject,1);
        component.set("v.isNavClicked",false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.isNavClicked",true)
            })
            ,500);
    },

    goLast : function (component,event,helper){
        var searchInput = component.get("v.searchInput");
        let searchObject = {
            'title' : searchInput
        };
        var lastPage = component.get('v.searchResponse.total_pages');
        component.set('v.actualPage',lastPage);
        helper.getResults(component,searchObject,lastPage);
        component.set("v.isNavClicked",false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.isNavClicked",true)
            })
            ,500);
    },



    redirectToDetails : function(component, event, helper) {
           component.set("v.movieId",event.currentTarget.id);
          var id = component.get("v.movieId");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_MovieDetails",
                componentAttributes: {
                    movieId : id
                }
            });
            evt.fire();
          component.set("v.loaded",false);
    }

})
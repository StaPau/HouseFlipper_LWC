({

    getGenres : function (component){
        var action = component.get("c.getGenres");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.genres",returnValue);
            }
        });
        $A.enqueueAction(action);
    },

    getCountries : function (component){
        var action = component.get("c.getCountries");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.countries",returnValue);
            }
        });
        $A.enqueueAction(action);
    },

    getTopMovies : function (component){
        var pageNow = component.get("v.actualPage");
        var action = component.get('c.getTopMovies');
        action.setParams({
            page:pageNow
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.moviesSearch",returnValue.results);
            }
        });
        $A.enqueueAction(action);
    },

    getResults : function (component,searchObject,page){
        var action = component.get("c.searchForMovies");
        action.setParams({
            search :{
                title : searchObject.title
            },
            page : page
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.moviesSearch",returnValue.results);
                component.set("v.searchResponse",returnValue);
            }
        });
        $A.enqueueAction(action);
    }



})
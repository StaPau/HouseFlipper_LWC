({

    doInit : function (component,event,helper){
        var queryString = window.location.search;
        var urlParams = new URLSearchParams(queryString);
        var movie = urlParams.get('c__id');
        component.set("v.movieId",movie);
//        component.set("v.movieId",parseInt(movie));
        var action = component.get("c.getMovieCast");
        action.setParams({
            id : parseInt(movie)
            });
        action.setCallback(this, function(response){
                    var state = response.getState();
                    if(state === "SUCCESS"){
                        var returnValue = response.getReturnValue();
                        component.set("v.cast",returnValue);
                    }
                });

        $A.enqueueAction(action);


    },

    redirectToDetails : function (component,event,helper){
        component.set("v.actorId",event.currentTarget.id);
        var actorId = component.get("v.actorId");
        var navService = component.find("navService");
          var pageReference = {
                type: 'standard__component',
                attributes: {
                 "componentName": "c__GM_ActorDetails"
               },
               state: {
                   "c__id": actorId
               }

          }
                    $A.get('e.force:refreshView').fire();
          navService.navigate(pageReference);

    }
})
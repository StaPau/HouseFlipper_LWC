({
    getPopularActors : function(component){
        var action = component.get("c.getPopularActors");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.actorsSearch",returnValue.results);
//                component.set("v.loaded",true);
            }
        });
        $A.enqueueAction(action);
    },

    getResults : function (component,name,page){
        console.log('name: '+name+', page: '+page);
        var action = component.get("c.searchActors");
        action.setParams({name : name,
                            page : page});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.actorsSearch",returnValue.results);
                component.set("v.searchResponse",returnValue);
            }
        });
        $A.enqueueAction(action);
    }

})
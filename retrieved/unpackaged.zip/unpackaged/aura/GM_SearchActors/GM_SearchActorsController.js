({

    onInit : function (component,event,helper){
        helper.getPopularActors(component);
    },

    searchButtonHandle : function (component,event,helper){
        var searchInput = component.get("v.searchInput");
//        console.log('search input: '+searchInput);
        var action = component.get("c.searchActors");
        action.setParams({name : searchInput,
                            page : 1});
        action.setCallback(this, function(response){
            var state = response.getState();
//            console.info('response', response);
//            console.log('state: '+state);

            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
//                console.log(returnValue);
                component.set("v.actorsSearch",returnValue.results);
                component.set('v.searchResponse',returnValue);
                component.set('v.isSearchClicked',true);
//                component.set("v.loaded",true);

            }
        });
//        console.log('input: '+searchInput);
//        console.log(component.get("v.actorsSearch"));
        $A.enqueueAction(action);
    },

        goNext : function (component,event,helper){
            var searchInput = component.get("v.searchInput");
            console.log(searchInput);
            var nextPage = component.get('v.actualPage')+1;
            var lastPage = component.get('v.searchResponse.total_pages');
            if(nextPage != lastPage+1){
                    console.log(nextPage);
                    component.set('v.actualPage',nextPage);
                    helper.getResults(component,searchInput,nextPage);
                    component.set("v.isNavClicked",false);
                    window.setTimeout(
                        $A.getCallback(function() {
                            component.set("v.isNavClicked",true)
                        })
                        ,500);
            }

        },

        goPrev : function (component,event,helper){
            var searchInput = component.get("v.searchInput");
            var prevPage = component.get('v.actualPage')-1;

            if(prevPage != 0){
                component.set('v.actualPage',prevPage);
                helper.getResults(component,searchInput,prevPage);
                component.set("v.isNavClicked",false);
                window.setTimeout(
                    $A.getCallback(function() {
                        component.set("v.isNavClicked",true)
                    })
                    ,500);
            }
        },

        goFirst : function (component, event, helper){
            var searchInput = component.get("v.searchInput");
    //        var page = component.get('v.actualPage')-1;
            component.set('v.actualPage',1);
            helper.getResults(component,searchInput,1);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        },

        goLast : function (component,event,helper){
            var searchInput = component.get("v.searchInput");
            var lastPage = component.get('v.searchResponse.total_pages');
            component.set('v.actualPage',lastPage);
            helper.getResults(component,searchInput,lastPage);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        },

    redirectToDetails : function(component, event, helper) {
            component.set("v.actorId",event.currentTarget.id);
            var id = component.get("v.actorId");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_ActorDetails",
                componentAttributes: {
                    actorId : id
                }
            });
            evt.fire();
     }
})
({
    doInit : function(component,event,helper){

//        var queryString = window.location.search;
//        var urlParams = new URLSearchParams(queryString);
//        var movie = urlParams.get('c__id');
//        component.set("v.movieId",parseInt(movie));
        var movie = component.get("v.movieId");
        var action = component.get("c.getMovie");
        action.setParams({
            id : parseInt(movie)
            });
        action.setCallback(this, function(response){
                var state = response.getState();
                if(state === "SUCCESS"){
                    var returnValue = response.getReturnValue();
                    var year = returnValue.release_date.substring(0,4);

                    component.set("v.movie",returnValue);
                    component.set("v.movie.release_date",year);
                    component.set("v.loaded",true);
                }
            });
        helper.getMovieCast(component);
        $A.enqueueAction(action);

    },

        redirectToDetails : function (component,event,helper){
            component.set("v.actorId",event.currentTarget.id);
            var id = component.get("v.actorId");
//            var navService = component.find("navService");
//              var pageReference = {
//                    type: 'standard__component',
//                    attributes: {
//                     "componentName": "c__GM_ActorDetails"
//                   },
//                   state: {
//                       "c__id": actorId
//                   }
//
//              }
////                        $A.get('e.force:refreshView').fire();
//              navService.navigate(pageReference);
//              component.set("v.loaded",false);
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_ActorDetails",
                componentAttributes: {
                    actorId : id
                }
            });
            evt.fire();
        },


       goNext7 : function (component, event, helper){
           if(component.get("v.end")<component.get("v.cast").length){
               component.set("v.start",component.get("v.start")+7);
               component.set("v.end", component.get("v.end") + 7);
           }
        event.preventDefault();

       },

       goPrev7 : function (component, event, helper){
           var arrowPrev = component.find("prev");
           if(component.get("v.start")>0){
//             $A.util.removeClass(arrowPrev,'noPrev');
             component.set("v.start",component.get("v.start")-7);
             component.set("v.end", component.get("v.end") - 7);

          }
//          if(component.get("v.start")==0){
//              $A.util.addClass(arrowPrev,'noPrev');
//          }
//          else{
//              $A.util.removeClass(arrowPrev,'noPrev');
//          }
//          else{
//              $A.util.addClass(arrowPrev,'noPrev');
//          }
      },

      afterScriptsLoaded : function(component, event, helper) {
          var domEl = component.find("ratingArea").getElement();
          var currentRating = component.get('v.value');
          var readOnly = component.get('v.readonly');
          var maxRating = 5;
          var callback = function(rating) {
              component.set('v.value',rating);
          }
          component.ratingObj = rating(domEl,currentRating,maxRating,callback,readOnly);
      },

      onValueChange: function(component,event,helper) {
          if (component.ratingObj) {
              var value = component.get('v.value');
              component.ratingObj.setRating(value,false);
          }
      }


})
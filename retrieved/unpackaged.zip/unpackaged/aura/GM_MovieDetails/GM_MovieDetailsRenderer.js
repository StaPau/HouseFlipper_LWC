({
    rerender : function(component,helper){
        this.superRerender();
        var movieId = component.get("v.movieId");
        console.log("rerender sie zrobil; v.movieId: "+movieId);
    }
})
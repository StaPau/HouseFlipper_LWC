({
    getActorMovies : function (component){
        var actor = component.get("v.actorId");
        var action = component.get("c.getActorsMovies");
        action.setParams({
            id : parseInt(actor)
            });
        action.setCallback(this, function(response){
                    var state = response.getState();
                    if(state === "SUCCESS"){
                        var returnValue = response.getReturnValue();
                        component.set("v.movies",returnValue);
                    }
                });
        $A.enqueueAction(action);
    }
})
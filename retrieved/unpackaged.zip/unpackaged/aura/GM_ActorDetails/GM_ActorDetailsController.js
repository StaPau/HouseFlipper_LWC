({
        doInit : function(component,event,helper){
            var actor = component.get("v.actorId");
            var action = component.get("c.getActor");
            action.setParams({
                id : parseInt(actor)
                });
            action.setCallback(this, function(response){
                        var state = response.getState();
                        if(state === "SUCCESS"){
                            var returnValue = response.getReturnValue();
                            component.set("v.actor",returnValue);
                            component.set("v.loaded",true);
                        }
                    });
            helper.getActorMovies(component);
            $A.enqueueAction(action);
        },

        redirectToDetails : function(component, event, helper) {
            component.set("v.movieId",event.currentTarget.id);
          var id = component.get("v.movieId");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_MovieDetails",
                componentAttributes: {
                    movieId : id
                }
            });
            evt.fire();
          component.set("v.loaded",false);
         },

        goNext7 : function (component, event, helper){
            if(component.get("v.end")<component.get("v.movies").length){
                component.set("v.start",component.get("v.start")+7);
                component.set("v.end", component.get("v.end") + 7);
            }
        },

        goPrev7 : function (component, event, helper){
            var arrowPrev = component.find("prev");

            if(component.get("v.start")>0){

              component.set("v.start",component.get("v.start")-7);
              component.set("v.end", component.get("v.end") - 7);
           }
          }
})
({
    searchButtonHandle : function(component,helper,event){

            var searchCountry=component.get("v.selectedCountry");
            var searchGenres = component.get("v.selectedGenres");
            var searchYear = component.get("v.selectedYear");

            if(searchCountry==''){
                searchCountry = undefined;
            }
            if(searchYear ==''){
                searchYear=undefined;
            }

             var action = component.get("c.getDiscoverMovies");
                         action.setParams({search : {
                                         country : searchCountry,
                                         genre : searchGenres,
                                         productionYear : searchYear
                                     },
                                     page : 1
                         });

                 action.setCallback(this, function(response){
                     var state = response.getState();
                     if(state === "SUCCESS"){
                         var returnValue = response.getReturnValue();
                         component.set("v.moviesSearch",returnValue.results);
                         component.set('v.searchResponse',returnValue);
                          component.set('v.isSearchClicked',true);
                     }
                 });

             $A.enqueueAction(action);
             component.find('results').scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});


    },

    doInit : function(component,event,helper){
        helper.getGenres(component);
        helper.getCountries(component);
        helper.getYears(component);
        component.set('v.loaded',true);
    },

    pickGenre : function (component,event,helper){
        component.set("v.genreId",event.currentTarget.id);
        var genre = component.get('v.genreId');
        helper.getGenreToFilter(component,genre);
    },

    setCountryName : function (component,event,helper){
        var countryId = component.get("v.selectedCountry");
        helper.getCountryName(component,countryId);
    },

    clearButtonHandle : function (component,event,helper){
        component.set("v.selectedCountry",'');
        component.set("v.selectedGenres",[]);
        component.set("v.selectedYear",'');
        component.set("v.genreName",[]);
        component.set("v.countryName",'');
        component.set("v.genreId",'');
        component.set("v.moviesSearch",[]);
        component.set('v.isSearchClicked',false);
    },

    goNext : function (component,event,helper){
        var searchCountry=component.get("v.selectedCountry");
        var searchGenres = component.get("v.selectedGenres");
        var searchYear = component.get("v.selectedYear");

        if(searchCountry==''){
            searchCountry = undefined;
        }
        if(searchYear ==''){
            searchYear=undefined;
        }
        var lastpage = component.get('v.searchResponse.total_pages');
        var nextPage = component.get('v.actualPage')+1;
        if(nextPage != lastpage+1){
            component.set('v.actualPage',nextPage);
            var searchObject = {
                'country' : searchCountry,
                'genre' : searchGenres,
                'productionYear' : searchYear
            }
            helper.getResults(component,searchObject,nextPage);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        }



    },

    goPrev : function (component,event,helper){
        var searchCountry=component.get("v.selectedCountry");
        var searchGenres = component.get("v.selectedGenres");
        var searchYear = component.get("v.selectedYear");

        if(searchCountry==''){
            searchCountry = undefined;
        }
        if(searchYear ==''){
            searchYear=undefined;
        }

        var page = component.get('v.actualPage')-1;
        if(page != 0){
            component.set('v.actualPage',page);
            var searchObject = {
                'country' : searchCountry,
                'genre' : searchGenres,
                'productionYear' : searchYear
            }
            helper.getResults(component,searchObject,page);
            component.set("v.isNavClicked",false);
            window.setTimeout(
                $A.getCallback(function() {
                    component.set("v.isNavClicked",true)
                })
                ,500);
        }

    },

    goFirst : function (component, event, helper){
        var searchCountry=component.get("v.selectedCountry");
        var searchGenres = component.get("v.selectedGenres");
        var searchYear = component.get("v.selectedYear");

        if(searchCountry==''){
            searchCountry = undefined;
        }
        if(searchYear ==''){
            searchYear=undefined;
        }

//        var page = component.get('v.actualPage')-1;
        component.set('v.actualPage',1);
        var searchObject = {
            'country' : searchCountry,
            'genre' : searchGenres,
            'productionYear' : searchYear
        }
        helper.getResults(component,searchObject,1);
        component.set("v.isNavClicked",false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.isNavClicked",true)
            })
            ,500);
    },

    goLast : function (component,event,helper){
        var searchCountry=component.get("v.selectedCountry");
        var searchGenres = component.get("v.selectedGenres");
        var searchYear = component.get("v.selectedYear");

        if(searchCountry==''){
            searchCountry = undefined;
        }
        if(searchYear ==''){
            searchYear=undefined;
        }

        var page = component.get('v.searchResponse.total_pages');
        console.log(page);
        component.set('v.actualPage',page);
        console.log(component.get('v.actualPage'));
        var searchObject = {
            'country' : searchCountry,
            'genre' : searchGenres,
            'productionYear' : searchYear
        }
        helper.getResults(component,searchObject,page);
        component.set("v.isNavClicked",false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.isNavClicked",true)
            })
            ,500);
    },

    redirectToDetails : function(component, event, helper) {
           component.set("v.movieId",event.currentTarget.id);
          var id = component.get("v.movieId");
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef : "c:GM_MovieDetails",
                componentAttributes: {
                    movieId : id
                }
            });
            evt.fire();
          component.set("v.loaded",false);
    }

})
({

    getGenres : function (component){
        var action = component.get("c.getGenres");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.genres",returnValue);
            }
        });
        $A.enqueueAction(action);
    },

    getGenreToFilter : function (component,genreid){
        var action = component.get("c.getGenre");
        action.setParams({
                id : genreid
            });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                var genreList = component.get('v.selectedGenres');
                var genreNameList = component.get('v.genreName');
                var genreIdList = component.get('v.genreIds');
                 console.log('list: ');
                 genreList.forEach(genre=>{console.log(genre)});
                 console.log('return: '+JSON.stringify(returnValue));
                var arraycontainsgenre = genreList.findIndex(x => x.id === returnValue.id);
                console.log('index: '+arraycontainsgenre);
                if(arraycontainsgenre !== -1){
                    genreList.splice(arraycontainsgenre,1);
                }
                else{
                    genreList.push(returnValue);
                }
                 component.set('v.selectedGenres',genreList);
            }
        });
    $A.enqueueAction(action);
    },

    getGenreName : function (component, id){
        var action = component.get("c.getGenreName");
        action.setParams({id:id});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                var genreNameList = component.get('v.genreName');
                var genreIdList = component.get('v.genreIds');
                var arraycontainsgenre = (genreNameList.findIndex(function(item){
                    return item.indexOf(returnValue)!==-1;
                }));
                if(genreNameList.includes(returnValue)){
                    genreNameList.splice(arraycontainsgenre,1);
                    console.log(genreNameList);
                }
                else{
                    genreNameList.push(returnValue);
                }
                 component.set('v.genreName',genreNameList);
            }
        });
        $A.enqueueAction(action);
    },

    getCountries : function (component){
        var action = component.get("c.getCountries");
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.countries",returnValue);
                console.log(returnValue);
            }
        });
        $A.enqueueAction(action);
    },

    getCountryName : function (component, id){
        var action = component.get("c.getCountryName");
        action.setParams({id:id});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var returnValue = response.getReturnValue();
                component.set("v.countryName",returnValue);
            }
        });
        $A.enqueueAction(action);
    },

    getYears : function (component){
        var yearList= [];
        for(let i = 2022;i>1894;i--){
            yearList.push(i);
        }
        component.set("v.years",yearList);

    },

    getResults : function (component, searchObject, page){
//        var searchCountry=component.get("v.selectedCountry");
//        var searchGenres = component.get("v.selectedGenres");
//        var searchYear = component.get("v.selectedYear");
//
//        if(searchCountry==''){
//            searchCountry = undefined;
//        }
//        if(searchYear ==''){
//            searchYear=undefined;
//        }
//        console.log('search: '+searchCountry+', '+searchGenres+', '+searchYear);
         var action = component.get("c.getDiscoverMovies");
         action.setParams({search : searchObject,
                            page : page
         });

             action.setCallback(this, function(response){
                 console.log(searchObject);
                 console.log('page: '+page);
                 var state = response.getState();
                 if(state === "SUCCESS"){
                     var returnValue = response.getReturnValue();
                     component.set("v.moviesSearch",returnValue.results);
                     component.set('v.searchResponse',returnValue);
                 }
             });
         $A.enqueueAction(action);
    }


})
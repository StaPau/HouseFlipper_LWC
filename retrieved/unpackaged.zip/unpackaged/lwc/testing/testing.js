/**
 * Created by paulina.starz on 28.10.2022.
 */

import { LightningElement } from 'lwc';

export default class Testing extends LightningElement {

  //comment 

}